""" running local blast """

# Some settings
blast_exe = "/usr/bin/blastall" # blast program
blast_db = "/opt/databases/uniprot_sprot.fasta" # Database
query="O23729.fasta"  # query sequence              
from Bio.Blast import NCBIStandalone
result_handle, error_handle = NCBIStandalone.blastall(blast_exe, "blastp",blast_db, query)
if (error_handle):
   print error_handle.read()
blast_results = result_handle.read()

# Next, we save this string in a file:
save_file = open("my_blast.xml", "w")
save_file.write(blast_results)
save_file.close()

import cStringIO as strio #module alias is sometimes helpful if you
                          #want to be able to switch modules at a
                          #later point

s=strio.StringIO()  #StringIO object - behaves like file, but stores data in string
print >> s, "hi there"
s.write("hi ho\n")
print "Read attempt one:", s.read() #is empty because the file-like object is at the end
print "Position", s.tell() #tells position of the read/write pointer
s.seek(1) #move to the beginning (1 is byte offset from start, so 2nd character)
print "Read attempt two:", s.read()
s.seek(1)
print >> s, "xxx", #comma at the end will block the new line
s.seek(1)
print "Read attempt three:", s.read()

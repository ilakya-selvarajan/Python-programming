import  xml.etree.cElementTree as ET

def shortenText(t,lim=10):
    if len(t)>lim:
        return t[:10]+"..."
    else:
        return t

def prettyPrint(f):
    tab=4
    pad=-tab
    for event,element in ET.iterparse(f,events=("start","end")):
        if event=="start":
            pad+=tab
        print (" "*pad)+event+" "+element.tag+"  "+shortenText(str(element.text).strip())
        if event=="end":
            pad-=tab
        
with open("remote_blast.xml","r") as f:
    prettyPrint(f)

# remote BLAST with ID
from Bio.Blast import NCBIWWW
fasta_string = open("m_cold.fasta").read()
result_handle = NCBIWWW.qblast("blastn", "nr", fasta_string)

#We could also have read in the FASTA file as a SeqRecord and then supplied just the sequence itself:
#from Bio import SeqIO
#record = SeqIO.read(open("m_cold.fasta"), format="fasta")
#result_handle = NCBIWWW.qblast("blastn", "nr", record.seq)

# Blasting with fasta formatted SeqRecord sets the title
# in results

#record = SeqIO.read(open("m_cold.fasta"), format="fasta")
#result_handle = NCBIWWW.qblast("blastn", "nr", record.format("fasta"))


save_file = open("remote_blast.xml", "w")
save_file.write(result_handle.read())
save_file.close()

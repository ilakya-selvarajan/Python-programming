from Bio.Blast.Applications import NcbiblastxCommandline
myblast='/usr/bin/blastp'
myquery='O23729.fasta'
resultfile="O23729.xml"
database="/opt/databases/uniprot_sprot.fasta"
command=NcbiblastxCommandline(cmd=myblast,query=myquery,db=database,evalue=0.00001,outfmt=5,out=resultfile)
print command

###stdout, stderr = command()
stderr=""
####print stdout
print stderr

if (not stderr):
  result_handle = open(resultfile)
  from Bio.Blast import NCBIXML
  blast_records = NCBIXML.parse(result_handle)
  for rec_idx, blast_record in enumerate(blast_records):
    for al_idx,alignment in enumerate(blast_record.alignments):
      for hsp_idx,hsp in enumerate(alignment.hsps):
        print '**** Record %d Alignment %d HSP %d ****'%(rec_idx,al_idx,hsp_idx)
        print 'sequence:', alignment.title
        print 'length:', alignment.length
        print repr(alignment)
        print repr(hsp)
else:
  print "error ",return_code


from Bio import AlignIO
alignments = list(AlignIO.parse("resampled.phy", "phylip"))
for alignment in alignments :
    print alignment
    print


from Bio import AlignIO
""" Converts pfam file to Clustal"""
alignments = AlignIO.parse(open("PF05371_seed.sth"), "stockholm")
handle = open("PF05371_seed.aln","w")
AlignIO.write(alignments, handle, "clustal")
handle.close()
# Or
count = AlignIO.convert("PF05371_seed.sth", "stockholm", "PF05371_seed.aln", "clustal")
print "Converted %i alignments" % count


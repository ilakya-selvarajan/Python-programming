#!/usr/bin/perl
($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
$date=$mday.".".($mon+1).".".($year+1900);
print "$date \n";



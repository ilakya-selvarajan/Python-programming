import subprocess
"""Using subprocess communication to parse alignment from Muscle"""
import sys
from Bio.Align.Applications import MuscleCommandline
muscle_cline = MuscleCommandline(input="opuntia.fasta")
child = subprocess.Popen(str(muscle_cline),
                          stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE,
                          shell=(sys.platform!="win32"))
from Bio import AlignIO
align = AlignIO.read(child.stdout, "fasta")
print align

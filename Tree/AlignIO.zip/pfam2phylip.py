from Bio import AlignIO
""" pfam to phylip """
alignment = AlignIO.read(open("PF05371_seed.sth"), "stockholm")
name_mapping = {}
mapF=open("PF05371_seed2phy.map","w")
for i, record in enumerate(alignment) :
    name_mapping[i] = record.id
    record.id = "seq%i" % i
    mapF.write(record.id+"= seq"+str(i)+"\n")
print name_mapping
   
handle = open("PF05371_seed.phy","w")
AlignIO.write([alignment], handle, "phylip") # list [alignment]
handle.close()


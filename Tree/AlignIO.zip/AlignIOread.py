from Bio import AlignIO
""" Example of  AlignIO.read() """
handle=open("PF05371_seed.sth")
alignment = AlignIO.read(handle, "stockholm")
print "Alignment length %i" % alignment.get_alignment_length()
print "Alignment:"
for record in alignment :
    print "%s - %s" % (record.seq, record.id)

handle.close()

print "dbXrefs:"
# dbxrefs
for record in alignment :
    if record.dbxrefs :
        print record.id, record.dbxrefs




# 
import os
from Bio.Align.Applications import MuscleCommandline
muscle_cline = MuscleCommandline(input="opuntia.fasta", out="opuntia.faa")
print muscle_cline
stdout, stderr = muscle_cline()



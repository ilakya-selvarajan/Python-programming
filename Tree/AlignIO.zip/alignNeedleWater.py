from Bio.Emboss.Applications import NeedleCommandline
needle_cline = NeedleCommandline(asequence="alpha.fasta", bsequence="beta.fasta",\
         gapopen=10, gapextend=0.5, outfile="needle.txt")
# in windows 
#needle_cline = NeedleCommandline(r"C:\EMBOSS\needle.exe",
#                                 asequence="alpha.faa", bsequence="beta.faa",
#                                  gapopen=10, gapextend=0.5, outfile="needle.txt")

# or
needle_cline = NeedleCommandline()
needle_cline.asequence="alpha.fasta"
needle_cline.bsequence="beta.fasta"
needle_cline.gapopen=10
needle_cline.gapextend=0.5
needle_cline.outfile="needle.txt"
# running needle
stdout, stderr = needle_cline() # creates needle.txt 
print stdout + stderr

from Bio import AlignIO
align = AlignIO.read("needle.txt", "emboss")
print align
"""
SingleLetterAlphabet() alignment with 2 rows and 149 columns
MV-LSPADKTNVKAAWGKVGAHAGEYGAEALERMFLSFPTTKTY...KYR HBA_HUMAN
MVHLTPEEKSAVTALWGKV--NVDEVGGEALGRLLVVYPWTQRF...KYH HBB_HUMAN
"""
from Bio.Emboss.Applications import WaterCommandline
water_cline = WaterCommandline(asequence="alpha.fasta", bsequence="beta.fasta",\
         gapopen=10, gapextend=0.5, outfile="water.txt")
stdout, stderr = water_cline() # creates needle.txt 
print stdout + stderr


align = AlignIO.read("water.txt", "emboss")
print align

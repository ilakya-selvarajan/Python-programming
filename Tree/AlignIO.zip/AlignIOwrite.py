from Bio.Align import MultipleSeqAlignment
from Bio.Alphabet import generic_dna
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
""" Creates three alignment objects and saves 
    them on file
"""
align1 = MultipleSeqAlignment([
              SeqRecord(Seq("ACTGCTAGCTAG", generic_dna), id="Alpha"),
              SeqRecord(Seq("ACT-CTAGCTAG", generic_dna), id="Beta"),
              SeqRecord(Seq("ACTGCTAGDTAG", generic_dna), id="Gamma"),
          ])

align2 = MultipleSeqAlignment([
              SeqRecord(Seq("GTCAGC-AG", generic_dna), id="Delta"),
              SeqRecord(Seq("GACAGCTAG", generic_dna), id="Epsilon"),
              SeqRecord(Seq("GTCAGCTAG", generic_dna), id="Zeta"),
          ])

align3=MultipleSeqAlignment([
              SeqRecord(id="Eta", seq=Seq("ACTAGTACAGCTG",generic_dna)),
              SeqRecord(id="Theta", seq=Seq("ACTAGTACAGCT-",generic_dna)),
              SeqRecord(id="Iota",  seq=Seq("-CTACTACAGGTG",generic_dna))
           ])



my_alignments = [align1, align2, align3]

from Bio import AlignIO
handle = open("my_example.phy", "w")
print "Saving alignments on my_example.phy"
AlignIO.write(my_alignments, handle, "phylip")
handle.close()

